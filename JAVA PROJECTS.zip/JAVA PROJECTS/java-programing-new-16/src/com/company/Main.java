package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {


        Scanner scanner1 = null,scanner2,scanner3=new Scanner(System.in);
        int a=scanner1.nextInt();
        


	Seyirci seyirci1=new Seyirci("emre");
    Seyirci seyirci2=new Seyirci("aysu");

        System.out.println("seyirci sayisi "+Seyirci.getSeyirci_sayisi());





    }


}
