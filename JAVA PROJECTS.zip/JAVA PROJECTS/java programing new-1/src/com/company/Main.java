package com.company;

public class Main {

    public static void main(String[] args) {



        Kopek kopek1=new Kopek("minnoş",30,150,4,32);

        kopek1.kos(10);



    }





}
