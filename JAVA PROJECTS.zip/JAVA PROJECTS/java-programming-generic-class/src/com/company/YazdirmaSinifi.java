package com.company;

public class YazdirmaSinifi<E> {


    public void yazdir(E[]dizi){
        for (E e:dizi
             ) {
            System.out.println(e);

        }





    }




}
