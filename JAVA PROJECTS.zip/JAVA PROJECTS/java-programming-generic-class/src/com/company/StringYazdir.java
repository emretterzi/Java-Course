package com.company;

public class StringYazdir {

    public static void stringyazdir1(String[]isim){


        for (String a:isim
             ) {
            System.out.println(a);

        }
    }



}
