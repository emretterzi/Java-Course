package com.company;

public class IntegerYazdir {

    public static void Integeryazdir1(Integer[] sayilar){

        for (Integer a:sayilar
             ) {
            System.out.println(a);

        }





    }
}
