package com.company;

public class CharYazdir {
    public static void charyazdir1(Character[]dizi){


        for (Character c:dizi

             ) {
            System.out.println(c);

        }





    }


}
