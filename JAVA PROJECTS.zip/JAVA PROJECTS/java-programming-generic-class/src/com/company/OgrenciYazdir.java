package com.company;

public class OgrenciYazdir {
    public static void ogrenci_yazdir(Ogrenci[]isim){

        for (Ogrenci a:isim
             ) {
            System.out.println(a);

        }





    }



}
