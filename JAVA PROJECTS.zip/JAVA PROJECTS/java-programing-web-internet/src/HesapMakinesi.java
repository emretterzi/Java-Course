import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URISyntaxException;

public class HesapMakinesi extends JFrame {
    private  int say;
    private JPanel Ana_Panel;
    private JLabel ilksayiJlabel;
    private JTextField ilksayiTextField;
    private JLabel ikincisayiJlabel;
    private JTextField ikincisayiTextField;
    private JButton toplamaButton;
    private JButton çıkarmaButton;
    private JButton çarpmaButton;
    private JButton bölmeButton;
    private JLabel Sonuc;




    public HesapMakinesi() {
        setContentPane(Ana_Panel);
        setTitle("Hesap Makinesi Uygulaması");
        setSize(450,300);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);


        toplamaButton.addActionListener(new ActionListener() {



            public void actionPerformed(ActionEvent e) {

                int ilksayi=Integer.valueOf(ilksayiTextField.getText());
                int ikincisayi=Integer.valueOf(ikincisayiTextField.getText());

                Sonuc.setText(String.valueOf(ilksayi+ikincisayi));







            }
        });
        çıkarmaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int ilksayi1=Integer.valueOf(ilksayiTextField.getText());
                int ikincisayi1=Integer.valueOf(ikincisayiTextField.getText());

                Sonuc.setText(String.valueOf("Sonuç= "+ ((double) ilksayi1-ikincisayi1)));




            }
        });
        çarpmaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {



                int ilksayi2=Integer.valueOf(ilksayiTextField.getText());
                int ikincisayi2=Integer.valueOf(ikincisayiTextField.getText());

                Sonuc.setText(String.valueOf("Sonuç= "+ilksayi2*ikincisayi2));


            }
        });
        bölmeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                int ilksayi=Integer.valueOf(ilksayiTextField.getText());
                int ikincisayi=Integer.valueOf(ikincisayiTextField.getText());

                Sonuc.setText(String.valueOf("Sonuç= "+(double)ilksayi/ikincisayi));


            }
        });
    }
    public static void main(String[] args) throws URISyntaxException, IOException {


        HesapMakinesi hesapMakinesi1 =new HesapMakinesi();



    }

}
