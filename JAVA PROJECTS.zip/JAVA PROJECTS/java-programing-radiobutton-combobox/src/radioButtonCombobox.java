import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedHashSet;
import java.util.Set;

public class radioButtonCombobox extends JFrame{
    private JRadioButton javaRadioButton;
    private JRadioButton pythonRadioButton;
    private JRadioButton phpRadioButton;
    private JButton gosterButton;

    private JPanel ana_panel;


    Set<String>diller=new LinkedHashSet<String>();



    public void goster(){
        String uyarı1="Şu diller seçildi";
        for (String dil:diller){

            uyarı1+=dil+" ";

        }
        JOptionPane.showMessageDialog(gosterButton,uyarı1);







    }
    public static void main(String[] args){


      radioButtonCombobox radioButtonCombobox1=new radioButtonCombobox();




    }








    public radioButtonCombobox() {
        setContentPane(ana_panel);
        setTitle("RadioBox Uygulaması");
        setSize(450,300);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);








        gosterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {



                if (javaRadioButton.isSelected()){

                    diller.add("Java");

                }
                else{
                    diller.remove("Java");

                } if (pythonRadioButton.isSelected()){

                    diller.add("Phython");

                }
                else{
                    diller.remove("Phyton");

                } if (phpRadioButton.isSelected()){

                    diller.add("Php");

                }
                else{
                    diller.remove("Php");

                }
                goster();

            }








            // String uyarı2="şu diller seçildi"+comboBoxdiller.getSelectedItem;
            // JOptionPane.showMessageDialog(gosterButton,uyarı2);
            //bu işlemleri yaparak comboboxtaki itemleri direkt yazdırabiliyoruz.

        });
    }


}
