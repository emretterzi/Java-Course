public class Main {
    public static void main(String[] args) {


       //User user1=new User("emre");
       //User user2=new User("sila");

        System.out.println(User.counter);







        //static kod blogları tek başlarına  nesne sayısı kadar oluşturulur
        // kod bloglarının başına 1 static yazıldığında
        // static kod blogları 1 kez oluşur
        // Static kod bloglarını belli  en baştam belirleidğimiz staticle çağırabiliyoruz





    }
}