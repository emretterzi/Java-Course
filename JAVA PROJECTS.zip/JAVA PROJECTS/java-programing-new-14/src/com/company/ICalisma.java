package com.company;

public interface ICalisma {
    void calisma();
}

