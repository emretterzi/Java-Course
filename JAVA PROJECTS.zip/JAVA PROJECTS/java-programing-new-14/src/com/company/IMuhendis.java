package com.company;

public interface IMuhendis {


    void askerlikdurumusorghula();
    String mezuniyet_ortalamasi(double derece);
    void adlisicil_sorgula();
    void is_tecrubesi(String[]array);







}
