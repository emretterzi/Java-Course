package com.company.emreterzi.packet1;

import com.company.emreterzi.packet2.AdayOgrenci;

public class Ogrenci implements AdayOgrenci {


    @Override
    public void ders_calis() {
        System.out.println("ders calisiyorum");

    }
}
