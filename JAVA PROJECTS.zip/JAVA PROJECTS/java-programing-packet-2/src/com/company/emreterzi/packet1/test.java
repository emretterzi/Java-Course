package com.company.emreterzi.packet1;

public class test {
    public static void main(String[] args) {
        Ogrenci ogrenci=new Ogrenci();

        ogrenci.ders_calis();

    }

}
