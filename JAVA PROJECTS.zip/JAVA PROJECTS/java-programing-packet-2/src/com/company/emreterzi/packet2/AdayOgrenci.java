package com.company.emreterzi.packet2;

public interface AdayOgrenci {

    void ders_calis();





}
