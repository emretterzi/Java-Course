package com.company;

import org.w3c.dom.Node;


import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {



    }
}
