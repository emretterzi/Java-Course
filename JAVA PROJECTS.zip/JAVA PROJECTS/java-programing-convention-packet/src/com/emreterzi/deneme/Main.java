package com.emreterzi.deneme;


import com.emreterzi.swing.Pencere;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {

       Pencere pencere=new Pencere();






    }



}
