public class Samurai extends  GameCharacter{

    public Samurai() {

        super(1,"Samurai",21,16,5);
    }
}
