import java.util.Scanner;

public class Player {

      private String name;
     private Integer health;
     private Integer money;
     private Integer damage;
     private  String charName;

    public Player(String name) {
        this.name = name;
    }


    public void selectChar(){
        GameCharacter[] charList ={new Samurai(),new Archer(),new Paladin()};

        System.out.println("------------------------------");
        for (GameCharacter gamecharacter:charList
             ) {
            System.out.println("Karakter"+gamecharacter.getName()+"\t Hasar:"+gamecharacter.getDamage()+
                    "\t Sağlık:" +gamecharacter.getHealth()+"\t Para:"+gamecharacter.getMoney());
            
        }
        Scanner scanner1=new Scanner(System.in);
        String selectChar=scanner1.nextLine();
        switch (selectChar) {
            case "Samurai" -> {
                Samurai samurai = new Samurai();
                this.setDamage(samurai.getDamage());
                this.setCharName(samurai.getName());
                this.setHealth(samurai.getHealth());
                this.setMoney(samurai.getMoney());


            }
            case "Archer" -> {
                Archer archer = new Archer();
                this.setDamage(archer.getDamage());
                this.setCharName(archer.getName());
                this.setHealth(archer.getHealth());
                this.setMoney(archer.getMoney());
            }
            case "Paladin" -> {
                Paladin paladin = new Paladin();
                this.setDamage(paladin.getDamage());
                this.setCharName(paladin.getName());
                this.setHealth(paladin.getHealth());
                this.setMoney(paladin.getMoney());
            }
            default -> System.out.println("yanlış karakter girdiniz");
        }
        System.out.println("Seçtiğiniz karakter: "+getCharName());


     }





     public void mainSelectLocal(){
        while (true){
                Location location=null;

                System.out.println("Bölgeler");
                System.out.println("1-Güvenli ev");
                System.out.println("2-Mağaza");
                System.out.println("Lütfen gitmek istediğiniz bölgeyi seçiniz");
                Scanner scanner1=new Scanner(System.in);
                int selectLocal=scanner1.nextInt();


            if(selectLocal!=1 && selectLocal!=2){

                System.out.println("lütfen doğru rakamı giriniz");
               continue;
            }
                switch (selectLocal){

                    case 1:
                        location=new SafeHouse(this);

                        break;

                    case 2: location=new ToolStore(this);

                        break;

                }







            if (!location.onLocation()) {

                System.out.println("GAME OVER");
                break;
            }



        }

     }
     public void selectLocal(){
        Location location=null;

         System.out.println("Bölgeler");
         System.out.println("1-Güvenli ev");
         System.out.println("2-Mağaza");
         System.out.println("Lütfen gitmek istediğiniz bölgeyi seçiniz");
         Scanner scanner1=new Scanner(System.in);
         int selectLocal=scanner1.nextInt();
         switch (selectLocal){

             case 1:
                location=new SafeHouse(this);
                 location.onLocation();
                    break;

             case 2: location=new ToolStore(this);
                 location.onLocation();
                 break;

            //default safehouse yaz bi ara

         }
     }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getHealth() {
        return health;
    }

    public void setHealth(Integer health) {
        this.health = health;
    }

    public Integer getMoney() {
        return money;
    }

    public void setMoney(Integer money) {
        this.money = money;
    }

    public Integer getDamage() {
        return damage;
    }

    public void setDamage(Integer damage) {
        this.damage = damage;
    }

    public String getCharName() {
        return charName;
    }

    public void setCharName(String charName) {
        this.charName = charName;
    }
}


