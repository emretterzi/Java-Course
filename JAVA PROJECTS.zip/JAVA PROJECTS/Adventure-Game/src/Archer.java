public class Archer extends GameCharacter{


    public Archer() {
        super(2,"Archer",18,20,7);
    }
}
