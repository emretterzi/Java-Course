public abstract class GameCharacter {

    private int id;
    private  String name;
    private Integer health;
    private Integer money;
    private Integer damage;


    public GameCharacter(int id, String name, Integer health, Integer money, Integer damage) {
        this.id = id;
        this.name = name;
        this.health = health;
        this.money = money;
        this.damage = damage;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getHealth() {
        return health;
    }

    public void setHealth(Integer health) {
        this.health = health;
    }

    public Integer getMoney() {
        return money;
    }

    public void setMoney(Integer money) {
        this.money = money;
    }

    public Integer getDamage() {
        return damage;
    }

    public void setDamage(Integer damage) {
        this.damage = damage;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
