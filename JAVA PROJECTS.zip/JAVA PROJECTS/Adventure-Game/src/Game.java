import jdk.swing.interop.SwingInterOpUtils;

import java.util.Scanner;

public class Game {
    private final Scanner scanner1=new Scanner(System.in);

    public void start(){


        System.out.println("MACERA OYUNUNA HOŞGELDİNİZ !");
        System.out.println("Lütfen Bir İsim Giriniz ");
        String playerName=scanner1.nextLine();
        Player player1=new Player(playerName);
        System.out.println("Merhaba "+ player1.getName()+" Bu zor ve korkunç maceraya hoşgeldin !. ");
        System.out.println("Lütfen bir karakter seçiniz");
        player1.selectChar();
        player1.mainSelectLocal();











    }
}
