public class Paladin extends GameCharacter{


    public Paladin() {
        super(3,"Paladin",24,5,8);
    }
}
