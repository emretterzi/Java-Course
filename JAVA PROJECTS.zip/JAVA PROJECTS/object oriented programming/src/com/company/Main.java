package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
Account account1=new Account("12345",1000,"emre","emrmail.com","532221992");


        account1.parayatir(500);
        account1.paracekme(2000);


        account1.bilgilerigöster();
    }
}
