package com.company;

public class Main {

    public static abstract class Aogrenci{
        private String isim;
        private  int numara;

        public Aogrenci(String isim, int numara) {
            this.isim = isim;
            this.numara = numara;
        }

        public String getIsim() {
            return isim;
        }

        public void setIsim(String isim) {
            this.isim = isim;
        }

        public int getNumara() {
            return numara;
        }

        public void setNumara(int numara) {
            this.numara = numara;
        }

        abstract void kayityaptir();
        public void selamla (){
            System.out.println("selamla");



        }






    }
    public interface IOgrenci{
        void ders_calis();
        void derse_gir();





    }

    //anaonim inner classı interface de kullanarak obje oluşturma
    //class oluşturmana gerek yok





    public static void main(String[] args) {
        IOgrenci ögrenci1=new IOgrenci() {
            @Override
            public void ders_calis() {
                System.out.println("ders calisiyorum");

            }

            @Override
            public void derse_gir() {
                System.out.println("derse giriyorum");

            }
        };

        ögrenci1.ders_calis();
        ögrenci1.derse_gir();
        System.out.println("------------------------------");

        Aogrenci aogrenci2=new Aogrenci("emre",10) {
            @Override
            void kayityaptir() {
                System.out.println("kayit yapiliyor.... isim= "+getIsim()+" numara= "+getNumara());


            }
        };
        aogrenci2.kayityaptir();
        aogrenci2.selamla();









    }






}
