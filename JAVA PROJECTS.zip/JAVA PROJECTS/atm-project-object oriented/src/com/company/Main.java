package com.company;

public class Main {

    public static void main(String[] args) {
        ATM atm1=new ATM();
        Account account1=new Account("emre","12345141",2000);

        atm1.calis(account1);

        System.out.println("programdan çıkılıyor");








    }
}
