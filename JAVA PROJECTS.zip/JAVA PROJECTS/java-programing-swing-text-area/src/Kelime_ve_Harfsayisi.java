import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Kelime_ve_Harfsayisi extends JFrame{
    private JTextArea yazi_alanı_text;
    private JPanel ana_panel;
    private JButton göster;
    private JLabel kelime_sayisi_label;
    private JLabel harf_sayisi_label;

    public Kelime_ve_Harfsayisi() {
        setContentPane(ana_panel);
        setTitle("Kelime Ve Harf Sayisini Bulma");
        setSize(450,300);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);









        göster.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String yazi1=yazi_alanı_text.getText();
                int karakter_sayisi=0;
                int kelime_sayisi=0;
                for (int i=0;i<yazi1.length();i++)
                {
                    if(yazi1.charAt(i) !=' '){
                        karakter_sayisi++;

                    }
                }
               String[] kelime_array= yazi1.split(" ");//kelime arayi tanımlayıp kelimeler üzernde gezinmek
                for (String kelime:kelime_array
                     ) {
                    kelime_sayisi++;


                }

               kelime_sayisi_label.setText("Kelime sayisi"+kelime_sayisi);harf_sayisi_label.setText("Harf sayisi"+karakter_sayisi);


            }
        });
    }
    public static void main(String[] args){


        Kelime_ve_Harfsayisi kelime_ve_harfsayisi1=new Kelime_ve_Harfsayisi();




    }
}
