package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner1=new Scanner(System.in);


        System.out.println("neva bugun kaç saat ders çalıştı");
        int zaman=scanner1.nextInt();


        if(zaman<4){

            System.out.println("sorumsuz kızz");
        }
        if (zaman>4){
            System.out.println("tatlı kızz");

        }
        

    }
}
