import jdk.dynalink.beans.StaticClass;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Deneme extends JFrame {
    private JTextField tf_ilk_isim;
    private JLabel İlk_isim;
    private JTextField tf_soy_isim;
    private JButton btn_ok;
    private JButton btn_clear;
    private JLabel Soy_isim;
    private JLabel Hosgeldin;
    private JPanel Ana_panel;


    public Deneme() {
        setContentPane(Ana_panel);
        setTitle("İsim-Soyisim Uygulaması");
        setSize(450,300);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);

        btn_ok.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String ilk_isim=tf_ilk_isim.getText();
                String soy_isim=tf_soy_isim.getText();
                Hosgeldin.setText("Hoşgeldin "+ilk_isim+"  "+soy_isim);



            }
        });
        btn_clear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tf_ilk_isim.setText("");
                tf_soy_isim.setText("");
                Hosgeldin.setText("");


            }
        });
    }


    public static void main(String[] args){


        Deneme i̇sim_soyisim1=new Deneme();



    }
}
