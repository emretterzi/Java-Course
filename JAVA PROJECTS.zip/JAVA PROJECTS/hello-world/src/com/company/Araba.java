package com.company;

public class Araba {

   private String renk;

   private int kapilar;
   private int tekerlekler;
   private String motor;
   private String model;







    public void sethModel(String model1) {
       this.model=model1;

   }

    public String getModel() {
        return model;
    }

    public String getMotor() {
        return motor;
    }


    public void setMotor(String motor) {
        this.motor = motor;
    }

    public String getRenk() {
        return renk;
    }

    public void setRenk(String renk) {
        this.renk = renk;
    }

    public int getTekerlekler() {
        return tekerlekler;
    }

    public void setTekerlekler(int tekerlekler) {
        this.tekerlekler = tekerlekler;
    }

    public int getKapılar() {
        return kapilar;
    }

    public void setKapılar(int kapilar) {
        this.kapilar = kapilar;
    }
}
