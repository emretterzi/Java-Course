package com.company;

public class Main {

public static void main(String []args){
    Araba araba1= new Araba();

araba1.sethModel("bmw");
    System.out.println("Arabanın modeli "+araba1.getModel());


araba1.setMotor("359hp");
    System.out.println("Arabanın motor gücü "+araba1.getMotor());
    araba1.setKapılar(4);
    System.out.println("Arabanın kapı sayısı "+araba1.getKapılar());
    araba1.setRenk("kırmızı");
    System.out.println("Arabanın rengi "+araba1.getRenk());

    araba1.setTekerlekler(4);
    System.out.println("Arabanın tekerlerk sayisi= "+araba1.getTekerlekler());


}



}





