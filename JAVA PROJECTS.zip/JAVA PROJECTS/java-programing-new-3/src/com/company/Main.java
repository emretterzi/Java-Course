package com.company;

public class Main {

    public static void main(String[] args) {
        GelismisAbone gelismisAbone1=new GelismisAbone("emre",200,"istanbul");


gelismisAbone1.bakiye_ogren();


    }
}
