package com.emreterzi.packet1;

public class Test {
    public static void main(String[] args) {
        Ogrenci ogrenci=new Ogrenci();

        ogrenci.ders_calis();

    }
}
