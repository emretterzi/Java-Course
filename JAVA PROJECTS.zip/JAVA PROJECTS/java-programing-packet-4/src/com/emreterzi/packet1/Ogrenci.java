package com.emreterzi.packet1;

import com.emreterzi.packet2.AdayOgrenci;

public class Ogrenci implements AdayOgrenci {
    @Override
    public void ders_calis() {
        System.out.println("ders calisiyorum");

    }
}
