package com.emreterzi.packet2;

public interface AdayOgrenci {
    void ders_calis();




}
