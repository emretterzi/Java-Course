package com.company;

import java.util.Scanner;

public class Matematik  {
    private double PI=Math.PI;

    public double getPI() {
        return PI;
    }

    public void setPI(double PI) {
        this.PI = PI;
    }

    public class Faktoriyal{

        public void Faktoriyal(){
            Scanner scanner1=new Scanner(System.in);
            System.out.println("bir sayi giriniz");
            int sayi=scanner1.nextInt();

            int faktoriyal=1;



            for(int i=1;i<=sayi;i++){
                faktoriyal=faktoriyal*i;

            }
            System.out.println("faktoriyal ="+faktoriyal);



        }

    }

    public class Asal{
        public boolean asal_mi(int sayi)
        {
            int i=2;
            while (i<sayi){

                if (sayi %i ==0){

                    return false;
                }
                i++;

            }
            return true;




        }













    }



    public class Alan{
        public void daire_alan(int yarıcap){
            System.out.println("dairenin alanı "+(yarıcap*yarıcap*PI));







        }





    }






}
