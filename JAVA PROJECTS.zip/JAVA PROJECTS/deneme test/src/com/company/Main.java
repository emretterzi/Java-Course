package com.company;

public class Main  {




    public static void main(String[] args){


        Matematik.Faktoriyal faktoriyal1=new Matematik().new Faktoriyal();

        //ilk matematiği oluştur ardından matematiğin içindeki faktoriyal, oluştur;








    }


}
