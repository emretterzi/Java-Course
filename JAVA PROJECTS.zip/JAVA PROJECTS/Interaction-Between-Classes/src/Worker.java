public class Worker {



    public String name;
    public int salary;

    public Worker(String name,int salary){

        this.name=name;
        this.salary=salary;
    }






}
