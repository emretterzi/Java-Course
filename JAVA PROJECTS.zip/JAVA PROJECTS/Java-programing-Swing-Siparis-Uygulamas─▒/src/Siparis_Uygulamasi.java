import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedHashSet;
import java.util.Set;

public class Siparis_Uygulamasi extends JFrame {
    private JPanel ana_panel;
    private JCheckBox javaCheckBox;
    private JCheckBox pythonCheckBox;
    private JCheckBox cCheckBox;
    private JLabel secilendiller;
    private JButton gösterButton;
    Set<String> set1=new LinkedHashSet<String>();
    public void label_degistir(){

        String yazi="Şu diller seçildi:";//set ile  gezinme for each döngüsü ile
        for (String dil:set1) {
            yazi += dil + ",  ";
        }
        secilendiller.setText(yazi);

    }


   public static void main(String[] args){

Siparis_Uygulamasi siparis_uygulamasi1=new Siparis_Uygulamasi();




    }

    public Siparis_Uygulamasi() {
        setContentPane(ana_panel);
        setTitle("Sipariş Uygulaması");
        setSize(450,300);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);












        gösterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(javaCheckBox.isSelected()){
                    set1.add("Java");



                }
                else{
                    set1.remove("Java");
                }
                if(pythonCheckBox.isSelected()){
                    set1.add("Python");



                }
                else{
                    set1.remove("Python");

                }
                if(cCheckBox.isSelected()){
                    set1.add("C++");



                }
                else{
                    set1.remove("C++");
                }
                label_degistir();








            }
        });
    }
}
