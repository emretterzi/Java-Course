package com.company;

public class Kare extends Sekil {
    private int kenar;

    @Override
    void alan_hesapla() {
        System.out.println(getIsim() + " alanı " + (kenar * kenar) + " dir");
    }


    public Kare(String isim, int kenar) {
        super(isim);
        this.kenar = kenar;
    }

    public void cevre_hesapla() {
        System.out.println(getIsim() + " çevresi " + (kenar * 4) + " dir ");
    }
}
