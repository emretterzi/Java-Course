package com.company;

public class Main {

    public static void main(String[] args) {
        Sekil sekil1 = new Kare("kare2", 6);

        Kare kare1 = new Kare("kare1", 5);

        Daire daire1 = new Daire("daire1", 3);

        kare1.alan_hesapla();
        daire1.alan_hesapla();
        sekil1.alan_hesapla();
        kare1.cevre_hesapla();
//abstract classı yazıyoruz çünkü diğer classlar kendilerine ait alan ve çevre hesaplamalarına sahip.
    }
}
