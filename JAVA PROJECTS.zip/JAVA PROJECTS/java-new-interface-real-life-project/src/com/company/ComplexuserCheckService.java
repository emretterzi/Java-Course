package com.company;

public class ComplexuserCheckService implements IuserCheckService{

    @Override
    public boolean checkUser(User user1) {

        if (user1.getAge()>=18&& user1.getName().startsWith("emre")){
            return true;

        }
        return false;

    }
}


