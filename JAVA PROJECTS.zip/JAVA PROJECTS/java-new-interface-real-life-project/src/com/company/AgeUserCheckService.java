package com.company;

public class AgeUserCheckService implements IuserCheckService {
    @Override
    public boolean checkUser(User user1) {

        if (user1.getAge()>=18){
            return true;

        }
        return false;


    }
}
