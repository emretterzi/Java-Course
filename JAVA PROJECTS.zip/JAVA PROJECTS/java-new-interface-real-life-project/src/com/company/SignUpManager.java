package com.company;

public class SignUpManager {
    private IuserCheckService iuserCheckService1;

    public SignUpManager(IuserCheckService iuserCheckService1) {
        this.iuserCheckService1 = iuserCheckService1;
    }

    public void signUp(User user1){

        if (iuserCheckService1.checkUser(user1)){
            System.out.println("kullanıcı kayıt oldu");

        }
        else
        {
            System.out.println("kullanıcı kayıt olamadı");
        }









    }
}
