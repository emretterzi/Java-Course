package com.company;

public class Main  {

    public static void main(String[] args) {
SignUpManager signUpManager1=new SignUpManager(new AgeUserCheckService());
signUpManager1.signUp(new User(1,"mustafa",26));



    }
}
