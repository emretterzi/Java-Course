package com.company;

public interface IuserCheckService {
    boolean checkUser(User user1);
    //interfacemizi iki farklı check servismizi kullanabilmek için yazdık.


}
