public class Player {

    public String name;
    public int id=10;
    public static int count=10;


    public Player(String name, int id) {
        this.name = name;
        this.id = id;
    }





}
