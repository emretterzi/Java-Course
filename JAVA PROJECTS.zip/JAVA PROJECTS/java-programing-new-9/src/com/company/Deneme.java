package com.company;

public class Deneme {
    public String isim;

    public Deneme(String isim) {
        this.isim = isim;


    }
    public void yaz(){

        System.out.println(isim);
    }
}
