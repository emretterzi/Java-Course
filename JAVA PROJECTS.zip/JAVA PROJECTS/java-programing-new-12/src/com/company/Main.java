package com.company;

import java.util.Locale;

public class Main {

    public static void main(String[] args) {
    String a="aysu";
    String b=new String("emre");

        System.out.println("0.indeks= "+b.charAt(0));//0. indeksi bulma
        System.out.println("son harf= "+b.charAt(b.length()-1));//son harfi bulma

        System.out.println(b.startsWith("emr"));//b değeri emr ile başlıyor mu
        System.out.println(b.endsWith("re"));//b değeri re ile bitiyor mu

        System.out.println(b.indexOf("e"));//e harfini ilk gördüğü indeks
        System.out.println(b.indexOf("t"));// t harfi indekste yok -1 sonucunu veriyor
        System.out.println(b.toLowerCase(Locale.ROOT));//büyük karakterlerin hepisini küçük yapıyor
        System.out.println(b.toUpperCase(Locale.ROOT));//küçük karakterlerin hepsini büyük yapıyrouz


        String c="1,2,3";
        int d=Integer.parseInt(c);//c ninn içindeki değerleri ıntegeryapmak








    }
}
