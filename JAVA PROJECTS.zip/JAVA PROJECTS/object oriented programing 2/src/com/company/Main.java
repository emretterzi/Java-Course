package com.company;

public class Main {

    public static void main(String[] args) {


Account account1 =new Account("10019",10000,"emre","emrtr@mail.com","0531771876");


        account1.bilgilerigöster();


        new Account("11001",100191,"aysu","asyu@mail.com","0440292").bilgilerigöster();






    }








}
