public class Main {
    public static void main(String[] args) {
        S



       Test<Integer> n1=new Test<>("emre");




        System.out.println("Hello world!");
    }
}