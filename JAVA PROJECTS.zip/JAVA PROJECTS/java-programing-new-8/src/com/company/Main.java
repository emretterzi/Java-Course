package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

int [] array1={1,2};
        System.out.println(Arrays.toString(array1));
       int [][] array3={{1,2},{3,4}};
       System.out.println(array3[0][1]);

        int [][] array4= new int[2][2];
        Scanner scanner1=new Scanner(System.in);
        System.out.println("lütfen 4 matris değerini  giriniz");

        for (int i=0;i<2;i++){


            for (int j=0;j<2;j++){

                array4[i][j]=scanner1.nextInt();
                //System.out.println(Arrays.deepToString(array4));


            }
        } System.out.println(Arrays.deepToString(array4));






    }
}
