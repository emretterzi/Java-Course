package com.company;

public class Calisan {


    private String calisanİsim;
    private  int maas;
    private  String departman;


    public Calisan(String calisanİsim, int maas, String departman) {
        this.calisanİsim = calisanİsim;
        this.maas = maas;
        this.departman = departman;
    }
public void calis(){
    System.out.println("Çalisan çalışıyor");



}
public void bilgilerigöster(){
    System.out.println("isim= "+calisanİsim);
    System.out.println("maas= "+maas);
    System.out.println("departman= "+departman)
    ;

}
public void depertman_degistir(String yeni_departman){


    System.out.println("departman değiştiriliyor");

this.departman=yeni_departman;


    System.out.println("yeni departman="+this.departman);



}

    public String getCalisanİsim() {
        return calisanİsim;
    }

    public void setCalisanİsim(String calisanİsim) {
        this.calisanİsim = calisanİsim;
    }

    public int getMaas() {
        return maas;
    }

    public void setMaas(int maas) {
        this.maas = maas;
    }

    public String getDepartman() {
        return departman;
    }

    public void setDepartman(String departman) {
        this.departman = departman;
    }
}
