package com.company;

public class Main {

    public static void main(String[] args) {

Yonetici yönetici1=new Yonetici("emre",4000,"it",10
);


yönetici1.bilgilerigöster();
yönetici1.zamyapmaistegi();





    }
}
