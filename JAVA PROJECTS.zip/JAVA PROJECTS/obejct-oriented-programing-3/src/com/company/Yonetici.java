package com.company;

import java.util.Scanner;

public class Yonetici extends Calisan{
    private int sorumlukisi;


    public Yonetici(String calisanİsim, int maas, String departman,int sorumlukisi) {
        super(calisanİsim, maas, departman);
        this.sorumlukisi=sorumlukisi;

    }





    public void zamyapmaistegi(){
        Scanner scanner=new Scanner(System.in);

        System.out.println("zam yapmak istiyorsanız 1 çıkış için 2");
        int giris=scanner.nextInt();


        if (giris==1){
            zamyap();



        }
        if(giris==2){
            return;


        }

    }

    public void zamyap(){
        Scanner scanner=new Scanner(System.in);
        System.out.println("lütfen zam miktarini giriniz=");
        int zam=scanner.nextInt();
        System.out.println("yapilan zam miktarı "+zam);
        System.out.println("yeni maaşınız "+(zam+getMaas()));






    }


    public int getSorumlukisi() {
        return sorumlukisi;
    }

    public void setSorumlukisi(int sorumlukisi) {
        this.sorumlukisi = sorumlukisi;
    }
}
