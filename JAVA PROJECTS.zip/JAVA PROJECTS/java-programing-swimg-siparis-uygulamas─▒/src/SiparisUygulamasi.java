import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.MessageFormat;
import java.util.LinkedHashMap;
import java.util.Map;

public class SiparisUygulamasi extends JFrame{
    private JPanel ana_panel;
    private JLabel menü_label;
    private JCheckBox iskenderCheckBox;
    private JCheckBox beytiCheckBox;
    private JCheckBox salataCheckBox;
    private JCheckBox ayranCheckBox;
    private JButton siparislerigosterButton;


    public static void main(String[] args){


        SiparisUygulamasi siparisUygulamasi1=new SiparisUygulamasi();





    }
    Map<String,Integer>siparisler=new LinkedHashMap<String ,Integer>();

public void siparislerigöster(){
    String uyarı="";
    int tutar=0;
    if (siparisler.isEmpty()){
        
        uyarı="Siparişiniz bulunmamaktadir";
        
    }
    else{uyarı+="Siparişler\n"+"-------------\n";

        for (Map.Entry<String,Integer>entry:siparisler.entrySet()){
            uyarı+=entry.getKey()+"\n";
            tutar+=entry.getValue();




        }
        uyarı+="Toplam tutar:"+tutar+"TL";

    }
JOptionPane.showMessageDialog(siparislerigosterButton,uyarı);//uyarı mesajı ile siparişleri göstermek

}










    public SiparisUygulamasi() {
        setContentPane(ana_panel);
        setTitle("Sipariş Verme Ekranı");
        setSize(450,300);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);









        siparislerigosterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               if (iskenderCheckBox.isSelected()){
                   siparisler.put("-İskender",15);
                }
               else
               {
                  siparisler.remove("-İskender");

               } if (beytiCheckBox.isSelected()){
                    siparisler.put("-Beyti",12);
                }
                else
                {
                    siparisler.remove("-Beyti");

                } if (salataCheckBox.isSelected()){
                    siparisler.put("-Salata",5);
                }
                else
                {
                    siparisler.remove("-Salata");


                } if (ayranCheckBox.isSelected()){
                    siparisler.put("-Ayran",2);
                }
                else
                {
                    siparisler.remove("-Ayran");

                }
                siparislerigöster();



            }
        });

    }
}
